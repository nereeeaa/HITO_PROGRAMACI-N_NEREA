<?php
session_start();
// Verificamos si se ha enviado el formulario con el nombre 'submit'
if(isset($_POST['submit'])) {
    // Incluimos el archivo de conexión a la base de datos
    include("../conexion.php");
    $con = conectar();
    // Escapa los caracteres especiales de la variable 'email' y la asigna a la variable '$email'
    $email = mysqli_real_escape_string($con, $_POST['email']);

    // Consulta en la base de datos para encontrar un registro con el email ingresado
    $sql = "SELECT * FROM registro WHERE email = '$email'";
    $query = mysqli_query($con, $sql);

    // Vemos si se encontró un registro con el email que hemos introducido
    if(mysqli_num_rows($query) == 1) {
        $row = mysqli_fetch_array($query);
        $_SESSION['id'] = $row['id'];
        $_SESSION['nombre'] = $row['nombre'];
        $_SESSION['apellidos'] = $row['apellidos'];
        $_SESSION['email'] = $row['email'];
        header("Location: index.html");
        // Establecemos una cookie con la dirección IP del usuario durante 1 hora
        setcookie('ip', $_SERVER['REMOTE_ADDR'], time() + 3600);
        // Establecemos una cookie para ver el usuario durante 1 h
        setcookie('usuario', $email, time() + 3600);
        exit();
    }
    else {
        //si no se cumple lo anterior significa que el usuario no estaria registrado y nos saca este mensaje
        echo "El usuario no existe";
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">
<link rel="stylesheet" href="CSS/normalize.css">
<link rel="stylesheet" href="webgrafía.html">
<link rel="stylesheet" href="JSON.html">
<link rel="stylesheet" href="XML.html">
<link rel="stylesheet" href="CONTACTO.html">
<link href="webgrafia.html">
<script src="https://kit.fontawesome.com/a7daddc7d9.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Iniciar Sesión</title>
</head>
<body>
    <div id="padre">
    <div id="arriba">
    <header id="encabezado_principal">
    <a id="logo-header" href="index.html">
    <span class="site-name">HITO GRUPAL </span>
    <div id="desaparece" class="desaparecer"><span class="site-desc !importante">NEREA RUIZ</span></div>
    </a>
    <div id="hamburguesa"><i class="fa-solid fa-2x fa-bars"></i></div>
    <nav id="menunavegacion">

    <ul class="desaparecer" id="desaparece">
    <li><a href="index.html">INICIO</a></li>
    <li><a href="XML.html">XML</a></li>
    <li><a href="CONTACTO.html">CONTACTO</a></li>
    </ul>
    </nav>
    </div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <h1 class="text-center mb-4">Iniciar Sesión</h1>
                <!--Aqui utilizamos esa variable ya que los datos tambien se van a procesar en esta pagina-->
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>
                    <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">Iniciar Sesión</button>
                </form>
                <p class="mt-3 text-center">¿No tienes una cuenta? <a href="registro.php">Regístrate</a></p>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Verifica si la cookie "usuario" está establecida
if(isset($_COOKIE['usuario'])) {
    $usuario = $_COOKIE['usuario'];
    echo "Bienvenido de nuevo, " . $usuario;
}
?>

