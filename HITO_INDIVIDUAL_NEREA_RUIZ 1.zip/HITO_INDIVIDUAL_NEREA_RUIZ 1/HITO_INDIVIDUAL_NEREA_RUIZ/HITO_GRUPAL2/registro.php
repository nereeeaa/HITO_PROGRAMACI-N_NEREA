<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-
scale=1.0">

<link rel="stylesheet" href="CSS/style.css">
<link rel="stylesheet" href="CSS/normalize.css">
<link rel="stylesheet" href="webgrafía.html">
<link rel="stylesheet" href="JSON.html">
<link rel="stylesheet" href="XML.html">
<link rel="stylesheet" href="CONTACTO.html">
<link href="webgrafia.html">
<script src="https://kit.fontawesome.com/a7daddc7d9.js" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<title>Registrate</title>
</head>
<body>
<div id="padre">
<div id="arriba">
<header id="encabezado_principal">
<a id="logo-header" href="index.html">
<span class="site-name">HITO GRUPAL </span>
<div id="desaparece" class="desaparecer"><span class="site-desc !importante">NEREA RUIZ</span></div>
</a>
<div id="hamburguesa"><i class="fa-solid fa-2x fa-bars"></i></div>
<nav id="menunavegacion">

<ul class="desaparecer" id="desaparece">
<li><a href="index.html">INICIO</a></li>
<li><a href="XML.html">XML</a></li>
<li><a href="CONTACTO.html">CONTACTO</a></li>
</ul>
</nav>
</div>
<div class="col-md-12">
                <H1>Regístrate</H1>
                <!--Le mandamos el action al archivo para insertar los usuarios en la bdd y lo mandamos por metodo post-->
                <form action="../registro/insertarregistro.php" method="post">
                    <input type="text" class="form-control mb-3" name="nombre" id="" placeholder="Nombre">
                    <input type="text" class="form-control mb-3" name="apellidos" id="" placeholder="Apellidos">
                    <input type="text" class="form-control mb-3" name="email" id="" placeholder="Email">
                    <input type="password" class="form-control mb-3" name="password" id="" placeholder="Password">
                    <input type="submit" class="btn btn-primary" value="Registrar">
                </form>
            </div>
</header>
</div>

</div>
</body>
</html>



