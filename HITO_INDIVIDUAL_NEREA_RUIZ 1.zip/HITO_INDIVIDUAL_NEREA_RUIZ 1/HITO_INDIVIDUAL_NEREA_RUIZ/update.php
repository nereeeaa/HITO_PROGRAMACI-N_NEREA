<?php
//incluimos el archivo que contiene la conexión a la base de datos
include("conexion.php");
$con=conectar();

//Obtenemos los valores enviados por el metodo post desde el formulario
$identrada=$_POST['identrada'];
$TituloEntrada=$_POST['TituloEntrada'];
$Info=$_POST['Info'];
$email=$_POST['email'];

//Creamos una consulta SQL para actualizar los valores en la tabla "programacion"
$sql="UPDATE programacion SET TituloEntrada='$TituloEntrada',Info='$Info',email='$email' WHERE identrada='$identrada'";
// Ejecutamos la consulta en la base de datos
$query=mysqli_query($con,$sql);

if($query){
    // Si la consulta se ejecutó correctamente, redireccionamos a la página "post.php"
    Header("Location: post.php");
}else{
    // ejecutamos un mensaje de error 
    echo "Ha ocurrido un problema";
}

?>