<?php
//CREAMOS UNA FUNCION PARA CONECTAR CON LA BASE DE DATOS
function conectar(){
    $host="localhost";
    $user="root";
    $pass="";
    $bd="hitobdd1";

    $con=mysqli_connect($host, $user, $pass);
    mysqli_select_db($con, $bd);

    return $con;

}
?>