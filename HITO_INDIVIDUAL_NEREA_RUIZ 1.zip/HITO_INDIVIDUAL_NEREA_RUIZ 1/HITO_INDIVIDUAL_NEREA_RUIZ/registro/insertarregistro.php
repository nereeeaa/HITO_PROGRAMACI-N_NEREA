<?php
include("../conexion.php");
$con=conectar();

$nombre=$_POST['nombre'];
$apellidos=$_POST['apellidos'];
$email=$_POST['email'];
$password=$_POST['password'];

// Validar si el correo electrónico ya está registrado
$sql_validar = "SELECT * FROM registro WHERE email='$email'";
$query_validar = mysqli_query($con, $sql_validar);
if (mysqli_num_rows($query_validar) > 0) {
    echo "El correo electrónico ya está registrado.";
} else {
    // Insertar el registro en la tabla
    $sql="INSERT INTO registro (nombre, apellidos, email, password) VALUES('$nombre', '$apellidos', '$email', '$password')";
    $query=mysqli_query($con,$sql);
    
    if($query){
        echo "Se ha registrado correctamente";
    }else{
        echo "Ha ocurrido un error al registrar el usuario.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
   <br><button onclick="location.href='../HITO_GRUPAL2/index.html'" class="btn btn-primary">Comenzar</button>
</body>
</html>