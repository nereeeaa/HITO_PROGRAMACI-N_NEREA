<?php
//incluimos el archivo que contiene la conexión a la base de datos
include("conexion.php");
$con=conectar();

// Obtenemos el valor del parámetro "id" enviado por GET en la URL
$identrada=$_GET['id'];

// Creamos una consulta SQL para eliminar la entrada correspondiente de la tabla "programacion"
$sql="DELETE FROM programacion WHERE identrada='$identrada'";
$query=mysqli_query($con,$sql);

if($query){
    // Si la consulta se ejecutó correctamente, redireccionamos a la página "post.php"
    Header("Location: post.php");
}else{
    // ejecutamos un mensaje de error 
    echo "Ha ocurrido un problema";
}

?>