<?php
include("conexion.php");
$con=conectar();

$TituloEntrada=$_POST['TituloEntrada'];
$Info=$_POST['Info'];
$email=$_POST['email'];

// Consultamos en la base de datos si el correo electrónico está registrado
$sql_verif = "SELECT * FROM registro WHERE email = '$email'";
$query_verif = mysqli_query($con, $sql_verif);

if(mysqli_num_rows($query_verif) == 1) {
    // El correo electrónico está registrado entonces si se puede agregar
    $sql="INSERT INTO programacion (TituloEntrada, Info, email) VALUES ('$TituloEntrada', '$Info', '$email')";
    $query=mysqli_query($con,$sql);

    if($query){
        Header("Location: post.php");
    } else {
        // En caso de que falle la consulta, se muestra un mensaje de error
        echo "Error al agregar el post";
    }
} else {
    // Si no esta registrado nos saltaria este mensaje 
    echo "El correo electrónico no está registrado";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>POST</title>
</head>
<body>
    <br><button onclick="location.href='HITO_GRUPAL2/registro.php'" class="btn btn-primary">REGISTRATE</button>
</body>
</html>