<?php 
// Incluimos el archivo de la conexion para la bd
include("conexion.php");
$con=conectar();
// Obtiene el valor del parámetro "id"
$id=$_GET['id'];
// Realiza una consulta a la base de datos para obtener los datos de la fila cuyo campo "identrada" coincida con el valor de "id" obtenido anteriormente
$sql="SELECT * FROM programacion WHERE identrada='$id'";
$query=mysqli_query($con,$sql);
// Obtiene la fila resultado de la consulta anterior y la guarda en la variable "row"
$row=mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <title>Actualizar</title>
</head>
<body>
    <div class="container mt-5">
        <form action="update.php" method="post">
            <!-- Incluye el valor del campo "identrada" obtenido de la consulta en un campo oculto del formulario -->
            <input type="hidden" name="identrada" value="<?php echo $row['identrada']?>">
                    <input type="text" class="form-control mb-3" name="TituloEntrada" id="" placeholder="Titulo de entrada" value="<?php echo $row['TituloEntrada']?>">
                    <input type="text" class="form-control mb-3" name="Info" id="" placeholder="Info" value="<?php echo $row['Info']?>">
                    <input type="text" class="form-control mb-3" name="email" id="" placeholder="Email" value="<?php echo $row['email']?>">
            <input type="submit" class="btn btn-primary btn-block" value="Actualizar">
        </form>
    </div>
</body>
</html>